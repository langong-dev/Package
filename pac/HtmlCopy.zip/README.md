# HtmlCopy

A copy js. Click to copy input or textarea. Made by JS.

# How to use it

## Install

1. Clone from Github.

```bash
# 1. Clone
git clone https://github.com/langong-dev/HtmlCopy.git
```

2. Copy to your server.

## Use

```html
<head>
  <script type="text/javascript" src="copy.js"></script>
</head>

...

<textarea id="copy">
  Some Thing To Copy.
</textarea>
<button onclick="Copy()">Click to Copy</button>
```

Feedback: ```langong-assist@foxmail.com```

# Made By LanGongDEV - 2020
