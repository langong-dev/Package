// Put Your Defines On Here


inline void creat_output() // Like Main
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%d",a+b);
}
