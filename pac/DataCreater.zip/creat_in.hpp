inline void creat_input()
{
	printf("%d %d",maxrand(50000),maxrand(50000));
}
